# python-flask-mock-rest-api
Mock Rest API implemented in python (with flask) and deployable to AWS Elastic Beanstalk.

11/14/2018 In progress...

## Overview

## Install

only two dependencies - flask and pytest
